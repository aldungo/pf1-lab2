# pf1-lab1
This is a test Lab 2 repository for demonstrating the creation of a GitHub assignment, using A.I. to help improve, then try out creating test cases to automate my code solutions.

**BEGIN DEMO**
Welcome to your Lab 2! If you made it here, that means you successfully accepted the assignment in Blackboard and are just about ready to begin coding

**Step 1**: Add your name to Line 2

**Step 2**: Add the date to Line 3

**Step 3**: Add the correct lab number to Line 4

**Step 4**: On line 13, add the proper print statement to display the following statement to the terminal 

*insert picture of terminal here*

Be mindful of syntax, double quotations, and parentheses. Don't forget the semicolon!

**Step 5**: Run the code and ensure the expected output displays. 

**END DEMO**